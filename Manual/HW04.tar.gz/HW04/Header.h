//
// Created by raf on 6/21/21.
//

#ifndef HW03_HEADER_H
#define HW03_HEADER_H

/**
 * @name Header
 * @brief Simple class to print the HW name and author name + any extra information using tabulate library.
 * God I love this library it's so fun to use.
 */

class Header {
public:
    void start();
};


#endif //HW03_HEADER_H
