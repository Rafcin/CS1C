#include "Lottery.h"

int main() {
    Lottery winners(51, 6);
    winners.print();
    return 0;
}
