//
// Created by raf on 6/21/21.
//

#ifndef HW03_HEADER_H
#define HW03_HEADER_H


class Header {
public:
    void start();
};


#endif //HW03_HEADER_H
